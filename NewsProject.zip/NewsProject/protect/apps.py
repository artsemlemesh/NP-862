from django.apps import AppConfig


class ProtectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'protect'
